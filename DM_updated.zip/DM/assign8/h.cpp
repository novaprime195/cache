#include <bits/stdc++.h>
using namespace std;

struct Cluster {
    vector<string> items;
    Cluster() {}
    Cluster(const string& name) { items.push_back(name); }
};
double getDistance(const map<pair<string, string>, double>& distMap,
                   const string& a, const string& b) {
    if (a == b) return 0;
    auto it = distMap.find({a, b});
    if (it != distMap.end()) return it->second;
    return distMap.at({b, a});
}
double clusterDistance(const Cluster& c1, const Cluster& c2,
                       const map<pair<string, string>, double>& distMap,
                       const string& method) {
    double minD = DBL_MAX, maxD = 0, sum = 0;
    int count = 0;

    for (auto& i : c1.items)
        for (auto& j : c2.items) {
            double d = getDistance(distMap, i, j);
            minD = min(minD, d);
            maxD = max(maxD, d);
            sum += d;
            count++;
        }

    if (method == "single") return minD;
    if (method == "complete") return maxD;
    return sum / count; // average
}
void hierarchicalClustering(const vector<string>& labels,
                            const map<pair<string, string>, double>& distMap,
                            const string& method) {
    vector<Cluster> clusters;
    for (auto& l : labels)
        clusters.push_back(Cluster(l));

    cout << "\n" << method << " LINKAGE CLUSTERING:\n";

    while (clusters.size() > 1) {
        double minDist = DBL_MAX;
        int a = -1, b = -1;

        for (int i = 0; i < clusters.size(); i++) {
            for (int j = i + 1; j < clusters.size(); j++) {
                double d = clusterDistance(clusters[i], clusters[j], distMap, method);
                if (d < minDist) {
                    minDist = d;
                    a = i;
                    b = j;
                }
            }
        }

        cout << "Merging (";
        for (auto& x : clusters[a].items) cout << x;
        cout << ") and (";
        for (auto& y : clusters[b].items) cout << y;
        cout << ") at distance = " << minDist << endl;

        Cluster merged;
        merged.items.insert(merged.items.end(),
                            clusters[a].items.begin(), clusters[a].items.end());
        merged.items.insert(merged.items.end(),
                            clusters[b].items.begin(), clusters[b].items.end());

        if (b > a) {
            clusters.erase(clusters.begin() + b);
            clusters.erase(clusters.begin() + a);
        } else {
            clusters.erase(clusters.begin() + a);
            clusters.erase(clusters.begin() + b);
        }

        clusters.push_back(merged);
    }
}
int main() {
    string filename = "h_input.csv";
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Error opening " << filename << endl;
        return 1;
    }
    string line;
    getline(file, line);
    vector<string> headers;
    stringstream ss(line);
    string val;
    getline(ss, val, ',');
    while (getline(ss, val, ','))
        headers.push_back(val);
    map<pair<string, string>, double> distMap;
    while (getline(file, line)) {
        stringstream ss(line);
        string rowLabel;
        getline(ss, rowLabel, ',');
        for (int i = 0; i < headers.size(); i++) {
            string cell;
            getline(ss, cell, ',');
            double d = stod(cell);
            distMap[{rowLabel, headers[i]}] = d;
        }
    }
    file.close();

    vector<string> linkages = {"single", "average", "complete"};
    for (auto& method : linkages)
        hierarchicalClustering(headers, distMap, method);

    return 0;
}


//Distance Matrix is given as input
// #include <iostream>
// #include <fstream>
// #include <sstream>
// #include <vector>
// #include <cmath>
// #include <string>
// #include <iomanip>
// #include <limits>
// #include <algorithm>

// using namespace std;

// // --- Read distance matrix CSV ---
// void read_distance_matrix(const string &filename, vector<string> &labels, vector<vector<double>> &dist) {
//     ifstream file(filename);
//     if (!file.is_open()) {
//         cerr << "Error: could not open file.\n";
//         return;
//     }

//     string line;
//     bool header = true;
//     while (getline(file, line)) {
//         if (line.empty()) continue;
//         stringstream ss(line);
//         string cell;
//         vector<string> row;
//         while (getline(ss, cell, ',')) row.push_back(cell);

//         if (header) {
//             for (size_t i = 1; i < row.size(); ++i)
//                 labels.push_back(row[i]);
//             header = false;
//         } else {
//             vector<double> vals;
//             for (size_t i = 1; i < row.size(); ++i)
//                 vals.push_back(stod(row[i]));
//             dist.push_back(vals);
//         }
//     }
// }

// // --- Read points CSV ---
// void read_points(const string &filename, vector<string> &labels, vector<vector<double>> &points) {
//     ifstream file(filename);
//     if (!file.is_open()) {
//         cerr << "Error: could not open file.\n";
//         return;
//     }

//     string line;
//     bool header = true;
//     while (getline(file, line)) {
//         if (line.empty()) continue;
//         stringstream ss(line);
//         string cell;
//         vector<string> row;
//         while (getline(ss, cell, ',')) row.push_back(cell);

//         if (header) {
//             header = false;
//             continue;
//         }

//         string label = row[0];
//         vector<double> coords;
//         for (size_t i = 1; i < row.size(); ++i)
//             coords.push_back(stod(row[i]));
//         labels.push_back(label);
//         points.push_back(coords);
//     }
// }

// // --- Compute Euclidean distance ---
// double euclidean(const vector<double> &a, const vector<double> &b) {
//     double sum = 0.0;
//     for (size_t i = 0; i < a.size(); ++i)
//         sum += pow(a[i] - b[i], 2);
//     return sqrt(sum);
// }

// // --- Build distance matrix ---
// vector<vector<double>> build_distance_matrix(const vector<vector<double>> &points) {
//     size_t n = points.size();
//     vector<vector<double>> dist(n, vector<double>(n, 0.0));
//     for (size_t i = 0; i < n; ++i) {
//         for (size_t j = i + 1; j < n; ++j) {
//             double d = euclidean(points[i], points[j]);
//             dist[i][j] = dist[j][i] = d;
//         }
//     }
//     return dist;
// }

// // --- Compute linkage distance between two clusters ---
// double linkage(const vector<int> &A, const vector<int> &B,
//                const vector<vector<double>> &dist, const string &method) {
//     if (method == "single") {
//         double min_d = numeric_limits<double>::infinity();
//         for (int i : A)
//             for (int j : B)
//                 min_d = min(min_d, dist[i][j]);
//         return min_d;
//     } else if (method == "complete") {
//         double max_d = 0.0;
//         for (int i : A)
//             for (int j : B)
//                 max_d = max(max_d, dist[i][j]);
//         return max_d;
//     } else { // average
//         double sum = 0.0;
//         int count = 0;
//         for (int i : A)
//             for (int j : B) {
//                 sum += dist[i][j];
//                 count++;
//             }
//         return sum / count;
//     }
// }

// // --- Print clusters ---
// void print_clusters(const vector<vector<int>> &clusters, const vector<string> &labels) {
//     cout << "\nCurrent Clusters:\n";
//     for (size_t i = 0; i < clusters.size(); ++i) {
//         cout << "Cluster " << i + 1 << ": [";
//         for (size_t j = 0; j < clusters[i].size(); ++j) {
//             cout << labels[clusters[i][j]];
//             if (j < clusters[i].size() - 1) cout << ", ";
//         }
//         cout << "]\n";
//     }
// }

// // --- Print distance matrix for clusters ---
// void print_distance_matrix(const vector<vector<int>> &clusters, const vector<string> &labels,
//                            const vector<vector<double>> &dist, const string &method) {
//     size_t n = clusters.size();
//     vector<vector<double>> matrix(n, vector<double>(n, 0.0));
//     vector<string> cluster_labels(n);

//     for (size_t i = 0; i < n; ++i) {
//         string lbl;
//         for (int idx : clusters[i]) lbl += labels[idx];
//         cluster_labels[i] = lbl;
//     }

//     for (size_t i = 0; i < n; ++i)
//         for (size_t j = i + 1; j < n; ++j)
//             matrix[i][j] = matrix[j][i] = linkage(clusters[i], clusters[j], dist, method);

//     cout << "\nDistance Matrix:\n";
//     cout << "              ";
//     for (const auto &lbl : cluster_labels)
//         cout << setw(15) << left << lbl;
//     cout << "\n";

//     for (size_t i = 0; i < n; ++i) {
//         cout << setw(14) << left << cluster_labels[i];
//         for (size_t j = 0; j < n; ++j) {
//             if (i == j)
//                 cout << setw(15) << left << "-";
//             else
//                 cout << setw(15) << left << fixed << setprecision(2) << matrix[i][j];
//         }
//         cout << "\n";
//     }
// }

// // --- Hierarchical clustering algorithm ---
// void hierarchical_cluster(const vector<string> &labels, const vector<vector<double>> &dist, const string &method) {
//     vector<vector<int>> clusters;
//     for (size_t i = 0; i < labels.size(); ++i)
//         clusters.push_back({static_cast<int>(i)});

//     int iteration = 1;

//     while (clusters.size() > 1) {
//         cout << "\n--- Iteration " << iteration << " ---";
//         print_clusters(clusters, labels);
//         print_distance_matrix(clusters, labels, dist, method);

//         double min_dist = numeric_limits<double>::infinity();
//         int mergeA = -1, mergeB = -1;

//         for (size_t i = 0; i < clusters.size(); ++i) {
//             for (size_t j = i + 1; j < clusters.size(); ++j) {
//                 double d = linkage(clusters[i], clusters[j], dist, method);
//                 if (d < min_dist) {
//                     min_dist = d;
//                     mergeA = i;
//                     mergeB = j;
//                 }
//             }
//         }

//         cout << "\nMerging clusters " << mergeA + 1 << " and " << mergeB + 1
//              << " (distance = " << fixed << setprecision(2) << min_dist << ")\n";

//         clusters[mergeA].insert(clusters[mergeA].end(),
//                                 clusters[mergeB].begin(),
//                                 clusters[mergeB].end());
//         clusters.erase(clusters.begin() + mergeB);

//         iteration++;
//     }

//     cout << "\n--- Final Cluster ---\n";
//     cout << "Final Cluster: [";
//     for (size_t i = 0; i < clusters[0].size(); ++i) {
//         cout << labels[clusters[0][i]];
//         if (i < clusters[0].size() - 1) cout << ", ";
//     }
//     cout << "]\n";
// }

// // --- Main program ---
// int main() {
//     string filename, file_type;
//     cout << "Enter CSV filename: ";
//     getline(cin, filename);
//     cout << "Is this a distance matrix or points CSV? (enter 'distance' or 'points'): ";
//     getline(cin, file_type);

//     vector<string> labels;
//     vector<vector<double>> dist;
//     vector<vector<double>> points;

//     if (file_type == "distance") {
//         read_distance_matrix(filename, labels, dist);
//     } else if (file_type == "points") {
//         read_points(filename, labels, points);
//         dist = build_distance_matrix(points);
//     } else {
//         cout << "Invalid choice! Please enter 'distance' or 'points'.\n";
//         return 0;
//     }

//     string method;
//     cout << "Enter linkage method (single / complete / average): ";
//     getline(cin, method);

//     if (method != "single" && method != "complete" && method != "average") {
//         cout << "Invalid method! Using single linkage by default.\n";
//         method = "single";
//     }

//     hierarchical_cluster(labels, dist, method);

//     return 0;
// }