#include <bits/stdc++.h>
using namespace std;

struct Point {
    vector<double> values;
    bool visited = false;
    int cluster = 0;

    Point(vector<double> vals) {
        values = vals;
    }

    double distance(const Point& other) const {
        double sum = 0.0;
        for (size_t i = 0; i < values.size(); i++)
            sum += pow(values[i] - other.values[i], 2);
        return sqrt(sum);
    }
};

vector<Point> readDataset(const string& filename) {
    vector<Point> points;
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error: Could not open file " << filename << endl;
        return points;
    }

    string line;
    bool firstLine = true;
    while (getline(file, line)) {
        if (firstLine) { 
            firstLine = false; 
            continue; 
        }
        if (line.empty()) continue;

        stringstream ss(line);
        string id, x, y;
        getline(ss, id, ',');  // skip Point ID
        getline(ss, x, ',');
        getline(ss, y, ',');

        points.emplace_back(vector<double>{stod(x), stod(y)});
    }

    file.close();
    return points;
}

vector<Point*> regionQuery(vector<Point>& dataset, Point& p, double eps) {
    vector<Point*> neighbors;
    for (auto& other : dataset) {
        if (p.distance(other) <= eps)
            neighbors.push_back(&other);
    }
    return neighbors;
}

void expandCluster(Point& p, vector<Point*>& neighbors, int clusterId,
                   vector<Point>& dataset, double eps, int minPts) {
    p.cluster = clusterId;
    queue<Point*> q;
    for (auto* n : neighbors) q.push(n);

    while (!q.empty()) {
        Point* current = q.front();
        q.pop();

        if (!current->visited) {
            current->visited = true;
            vector<Point*> newNeighbors = regionQuery(dataset, *current, eps);
            if ((int)newNeighbors.size() >= minPts) {
                for (auto* np : newNeighbors) q.push(np);
            }
        }

        if (current->cluster == 0)
            current->cluster = clusterId;
    }
}

void dbscan(vector<Point>& dataset, double eps, int minPts) {
    int clusterId = 0;
    for (auto& p : dataset) {
        if (!p.visited) {
            p.visited = true;
            vector<Point*> neighbors = regionQuery(dataset, p, eps);
            if ((int)neighbors.size() < minPts) {
                p.cluster = -1; // noise
            } else {
                clusterId++;
                expandCluster(p, neighbors, clusterId, dataset, eps, minPts);
            }
        }
    }
}

int main() {
    string filename = "input.csv"; 
    vector<Point> dataset = readDataset(filename);

    if (dataset.empty()) {
        cout << "Dataset not found or empty!" << endl;
        return 0;
    }

    double eps;
    int minPts;
    cout << "Enter epsilon (eps): ";
    cin >> eps;
    cout << "Enter minimum points (minPts): ";
    cin >> minPts;

    dbscan(dataset, eps, minPts);

    unordered_map<int, int> clusterCount;
    for (auto& p : dataset)
        clusterCount[p.cluster]++;

    int total = dataset.size();
    cout << "\nCluster Percentage Distribution:\n";
    for (auto& kv : clusterCount) {
        string name = (kv.first == -1) ? "Noise" : "Cluster " + to_string(kv.first);
        double percent = (kv.second * 100.0) / total;
        cout << name << ": " << kv.second << " points (" << fixed << setprecision(2) << percent << "%)\n";
    }

    return 0;
}



//Distance Matrix is given as input
// #include <iostream>
// #include <fstream>
// #include <sstream>
// #include <vector>
// #include <cmath>
// #include <string>
// #include <iomanip>
// #include <map>
// #include <algorithm>

// using namespace std;

// // --- Euclidean distance ---
// double distance(const vector<double>& a, const vector<double>& b) {
//     double sum = 0.0;
//     for (size_t i = 0; i < a.size(); ++i)
//         sum += pow(a[i] - b[i], 2);
//     return sqrt(sum);
// }

// // --- Compute centroid of a cluster ---
// vector<double> centroid(const vector<pair<string, vector<double>>>& cluster) {
//     if (cluster.empty()) return {};
//     size_t dims = cluster[0].second.size();
//     vector<double> mean(dims, 0.0);

//     for (const auto& p : cluster) {
//         for (size_t i = 0; i < dims; ++i)
//             mean[i] += p.second[i];
//     }
//     for (double& x : mean)
//         x /= cluster.size();
//     return mean;
// }

// // --- Read CSV of raw points ---
// vector<pair<string, vector<double>>> read_points_csv(const string& filename) {
//     vector<pair<string, vector<double>>> points;
//     ifstream file(filename);
//     if (!file.is_open()) {
//         cerr << "Error: cannot open file.\n";
//         return points;
//     }

//     string line;
//     bool header = true;
//     while (getline(file, line)) {
//         if (line.empty()) continue;
//         stringstream ss(line);
//         string cell;
//         vector<string> tokens;

//         while (getline(ss, cell, ','))
//             tokens.push_back(cell);

//         if (header) {
//             header = false;
//             continue;
//         }

//         try {
//             string name = tokens[0];
//             vector<double> coords;
//             for (size_t i = 1; i < tokens.size(); ++i)
//                 coords.push_back(stod(tokens[i]));
//             points.push_back({ name, coords });
//         } catch (...) {
//             continue;
//         }
//     }
//     return points;
// }

// // --- Read CSV of distance matrix ---
// void read_distance_matrix_csv(const string& filename, vector<string>& labels, vector<vector<double>>& matrix) {
//     ifstream file(filename);
//     if (!file.is_open()) {
//         cerr << "Error: cannot open file.\n";
//         return;
//     }

//     string line;
//     bool header = true;
//     while (getline(file, line)) {
//         if (line.empty()) continue;
//         stringstream ss(line);
//         string cell;
//         vector<string> tokens;
//         while (getline(ss, cell, ','))
//             tokens.push_back(cell);

//         if (header) {
//             for (size_t i = 1; i < tokens.size(); ++i)
//                 labels.push_back(tokens[i]);
//             header = false;
//         } else {
//             vector<double> row;
//             for (size_t i = 1; i < tokens.size(); ++i)
//                 row.push_back(stod(tokens[i]));
//             matrix.push_back(row);
//         }
//     }
// }

// // --- Compute distance matrix for points ---
// vector<vector<double>> compute_distance_matrix(const vector<pair<string, vector<double>>>& points) {
//     size_t n = points.size();
//     vector<vector<double>> matrix(n, vector<double>(n, 0.0));

//     for (size_t i = 0; i < n; ++i) {
//         for (size_t j = i + 1; j < n; ++j) {
//             double d = distance(points[i].second, points[j].second);
//             matrix[i][j] = matrix[j][i] = d;
//         }
//     }
//     return matrix;
// }

// // --- Print distance matrix ---
// void print_distance_matrix(const vector<string>& names, const vector<vector<double>>& matrix) {
//     cout << "\nDistance Matrix:\n";
//     cout << "            ";
//     for (const auto& name : names)
//         cout << setw(10) << name;
//     cout << "\n";

//     for (size_t i = 0; i < matrix.size(); ++i) {
//         cout << setw(10) << names[i] << " ";
//         for (double val : matrix[i])
//             cout << setw(10) << fixed << setprecision(2) << val;
//         cout << "\n";
//     }
// }

// // --- Region Query ---
// vector<int> region_query(const vector<pair<string, vector<double>>>& points,
//                          const vector<vector<double>>& matrix,
//                          int point_idx, double eps) {
//     vector<int> neighbors;
//     for (size_t j = 0; j < points.size(); ++j) {
//         if (matrix[point_idx][j] <= eps)
//             neighbors.push_back(j);
//     }
//     return neighbors;
// }

// // --- Expand cluster ---
// void expand_cluster(const vector<pair<string, vector<double>>>& points,
//                     const vector<vector<double>>& matrix,
//                     vector<int>& clusters, int cluster_id,
//                     int point_idx, vector<int>& neighbors,
//                     double eps, int min_pts) {
//     clusters[point_idx] = cluster_id;
//     vector<int> queue = neighbors;

//     while (!queue.empty()) {
//         int q_idx = queue.front();
//         queue.erase(queue.begin());

//         if (clusters[q_idx] == 0) { // unvisited
//             clusters[q_idx] = cluster_id;
//             vector<int> q_neighbors = region_query(points, matrix, q_idx, eps);
//             if ((int)q_neighbors.size() >= min_pts)
//                 queue.insert(queue.end(), q_neighbors.begin(), q_neighbors.end());
//         } else if (clusters[q_idx] == -1) { // noise
//             clusters[q_idx] = cluster_id;
//         }
//     }
// }

// // --- DBSCAN algorithm ---
// pair<vector<vector<pair<string, vector<double>>>>, vector<int>>
// dbscan(const vector<pair<string, vector<double>>>& points,
//        const vector<vector<double>>& matrix, double eps, int min_pts) {
//     int n = points.size();
//     vector<int> clusters(n, 0);
//     int cluster_id = 0;

//     for (int i = 0; i < n; ++i) {
//         if (clusters[i] != 0) continue;
//         vector<int> neighbors = region_query(points, matrix, i, eps);
//         if ((int)neighbors.size() < min_pts) {
//             clusters[i] = -1;
//         } else {
//             cluster_id++;
//             expand_cluster(points, matrix, clusters, cluster_id, i, neighbors, eps, min_pts);
//         }
//     }

//     map<int, vector<pair<string, vector<double>>>> cluster_map;
//     for (int i = 0; i < n; ++i)
//         if (clusters[i] > 0)
//             cluster_map[clusters[i]].push_back(points[i]);

//     vector<vector<pair<string, vector<double>>>> result;
//     for (auto& kv : cluster_map)
//         result.push_back(kv.second);

//     return { result, clusters };
// }

// // --- Main program ---
// int main() {
//     string filename, file_type;
//     cout << "Enter CSV filename: ";
//     getline(cin, filename);
//     cout << "Is this a distance matrix or points CSV? (enter 'distance' or 'points'): ";
//     getline(cin, file_type);

//     vector<pair<string, vector<double>>> points;
//     vector<string> labels;
//     vector<vector<double>> matrix;

//     if (file_type == "distance") {
//         read_distance_matrix_csv(filename, labels, matrix);
//         for (const auto& name : labels)
//             points.push_back({ name, {} });
//     } else if (file_type == "points") {
//         points = read_points_csv(filename);
//         for (const auto& p : points)
//             labels.push_back(p.first);
//         matrix = compute_distance_matrix(points);
//     } else {
//         cout << "Invalid choice! Please enter 'distance' or 'points'.\n";
//         return 0;
//     }

//     print_distance_matrix(labels, matrix);

//     double eps;
//     int min_pts;
//     cout << "\nEnter epsilon: ";
//     cin >> eps;
//     cout << "Enter minPts: ";
//     cin >> min_pts;

//     auto [clusters, cluster_assignments] = dbscan(points, matrix, eps, min_pts);

//     int total_points = points.size();
//     cout << "\nResults:\n";
//     for (size_t i = 0; i < clusters.size(); ++i) {
//         double percent = clusters[i].size() * 100.0 / total_points;
//         cout << "Cluster " << i + 1 << ": " << clusters[i].size()
//              << " points (" << fixed << setprecision(2) << percent << "%) → [";
//         for (size_t j = 0; j < clusters[i].size(); ++j) {
//             cout << clusters[i][j].first;
//             if (j < clusters[i].size() - 1) cout << ", ";
//         }
//         cout << "]\n";
//     }

//     vector<string> noise_points;
//     for (size_t i = 0; i < cluster_assignments.size(); ++i)
//         if (cluster_assignments[i] == -1)
//             noise_points.push_back(points[i].first);

//     if (!noise_points.empty()) {
//         double noise_percent = noise_points.size() * 100.0 / total_points;
//         cout << "Noise points: " << noise_points.size()
//              << " (" << fixed << setprecision(2) << noise_percent << "%) → [";
//         for (size_t i = 0; i < noise_points.size(); ++i) {
//             cout << noise_points[i];
//             if (i < noise_points.size() - 1) cout << ", ";
//         }
//         cout << "]\n";
//     }

//     if (file_type == "points") {
//         cout << "\nCentroids:\n";
//         for (size_t i = 0; i < clusters.size(); ++i) {
//             vector<double> c = centroid(clusters[i]);
//             cout << "Centroid " << i + 1 << ": [";
//             for (size_t j = 0; j < c.size(); ++j) {
//                 cout << fixed << setprecision(2) << c[j];
//                 if (j < c.size() - 1) cout << ", ";
//             }
//             cout << "]\n";
//         }
//     }

//     return 0;
// }