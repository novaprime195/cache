import csv
import math


# --- Read distance matrix CSV ---
def read_distance_matrix(filename):
    labels = []
    dist = []
    with open(filename, newline='') as csvfile:
        reader = csv.reader(csvfile)
        header = True
        for row in reader:
            if header:
                labels = [x.strip() for x in row[1:]]
                header = False
            else:
                values = list(map(float, row[1:]))
                dist.append(values)
    return labels, dist


# --- Read point coordinates CSV ---
def read_points(filename):
    labels = []
    points = []
    with open(filename, newline='') as csvfile:
        reader = csv.reader(csvfile)
        header = True
        for row in reader:
            if header:
                header = False
                continue
            label = row[0].strip()
            coords = list(map(float, row[1:]))
            labels.append(label)
            points.append(coords)
    return labels, points


# --- Compute Euclidean distance between two points ---
def euclidean(p1, p2):
    return math.sqrt(sum((a - b) ** 2 for a, b in zip(p1, p2)))


# --- Build distance matrix from points ---
def build_distance_matrix(points):
    n = len(points)
    dist = [[0.0] * n for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            d = euclidean(points[i], points[j])
            dist[i][j] = dist[j][i] = d
    return dist


# --- Compute linkage distance between two clusters ---
def linkage(A, B, dist, method):
    if method == "single":
        return min(dist[i][j] for i in A for j in B)
    elif method == "complete":
        return max(dist[i][j] for i in A for j in B)
    else:  # average
        vals = [dist[i][j] for i in A for j in B]
        return sum(vals) / len(vals)


# --- Print current clusters ---
def print_clusters(clusters, labels):
    print("\nCurrent Clusters:")
    for idx, cluster in enumerate(clusters, start=1):
        names = [labels[i] for i in cluster]
        print(f"Cluster {idx}: {names}")


# --- Print current distance matrix ---
def print_distance_matrix(clusters, labels, dist, method):
    n = len(clusters)
    matrix = [[0.0] * n for _ in range(n)]
    cluster_labels = ["".join(labels[i] for i in c) for c in clusters]

    for i in range(n):
        for j in range(i + 1, n):
            matrix[i][j] = matrix[j][i] = linkage(clusters[i], clusters[j], dist, method)

    print("\nDistance Matrix:")
    print("              ", end="")
    for lbl in cluster_labels:
        print(f"{lbl:<15}", end="")
    print()

    for i in range(n):
        print(f"{cluster_labels[i]:<14}", end="")
        for j in range(n):
            if i == j:
                print(f"{'-':<15}", end="")
            else:
                print(f"{matrix[i][j]:<15.2f}", end="")
        print()


# --- Hierarchical clustering main algorithm ---
def hierarchical_cluster(labels, dist, method):
    clusters = [[i] for i in range(len(labels))]
    iteration = 1

    while len(clusters) > 1:
        print(f"\n--- Iteration {iteration} ---")
        print_clusters(clusters, labels)
        print_distance_matrix(clusters, labels, dist, method)

        min_dist = float("inf")
        mergeA, mergeB = -1, -1

        for i in range(len(clusters)):
            for j in range(i + 1, len(clusters)):
                d = linkage(clusters[i], clusters[j], dist, method)
                if d < min_dist:
                    min_dist = d
                    mergeA, mergeB = i, j

        print(f"\nMerging clusters {mergeA + 1} and {mergeB + 1} (distance = {min_dist:.2f})")

        clusters[mergeA].extend(clusters[mergeB])
        del clusters[mergeB]
        iteration += 1

    final_names = [labels[i] for i in clusters[0]]
    print("\n--- Final Cluster ---")
    print("Final Cluster:", final_names)


# --- Main program ---
def main():
    filename = input("Enter CSV filename: ").strip()
    file_type = input("Is this a distance matrix or points CSV? (enter 'distance' or 'points'): ").strip().lower()

    if file_type == "distance":
        labels, dist = read_distance_matrix(filename)
    elif file_type == "points":
        labels, points = read_points(filename)
        dist = build_distance_matrix(points)
    else:
        print("Invalid choice! Please enter 'distance' or 'points'.")
        return

    method = input("Enter linkage method (single / complete / average): ").strip().lower()
    if method not in {"single", "complete", "average"}:
        print("Invalid method! Using single linkage by default.")
        method = "single"

    hierarchical_cluster(labels, dist, method)


if __name__ == "__main__":
    main()

# import math

# def distance(a, b):
#     return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))

# def centroid(cluster):
#     dims = len(cluster[0][1]) 
#     mean = [0.0] * dims
#     for _, p in cluster:
#         for i in range(dims):
#             mean[i] += p[i]
#     mean = [x / len(cluster) for x in mean]
#     return mean

# def read_csv(filename):
#     points = []
#     with open(filename, "r") as f:
#         header_skipped = False
#         for line in f:
#             line = line.strip()
#             if not line:
#                 continue
#             vals = line.split(",")
#             if not header_skipped and any("id" in v.lower() for v in vals):
#                 header_skipped = True
#                 continue
#             try:
#                 name = vals[0] 
#                 coords = [float(v) for v in vals[1:]]
#                 points.append((name, coords))
#             except:
#                 continue
#     return points

# def linkage_distance(clusterA, clusterB, method):
#     if method == "single":
#         return min(distance(a[1], b[1]) for a in clusterA for b in clusterB)
#     elif method == "complete":
#         return max(distance(a[1], b[1]) for a in clusterA for b in clusterB)
#     else:  
#         total = sum(distance(a[1], b[1]) for a in clusterA for b in clusterB)
#         count = len(clusterA) * len(clusterB)
#         return total / count

# def print_distance_matrix(clusters, method):
#     n = len(clusters)
#     matrix = [[0.0]*n for _ in range(n)]
#     labels = [",".join(p[0] for p in cluster) for cluster in clusters]

#     for i in range(n):
#         for j in range(n):
#             if i == j:
#                 matrix[i][j] = 0.0
#             elif i < j:
#                 d = linkage_distance(clusters[i], clusters[j], method)
#                 matrix[i][j] = d
#                 matrix[j][i] = d

#     print("\nDistance Matrix:")
#     print("           " + " ".join(f"{lbl:10}" for lbl in labels))
#     for i, row in enumerate(matrix):
#         print(f"{labels[i]:10} " + " ".join(f"{x:<10.2f}" for x in row))
#     return matrix

# def print_clusters(clusters):
#     print("\nCurrent Clusters and Centroids:")
#     for i, cluster in enumerate(clusters):
#         names = [p[0] for p in cluster]
#         c = centroid(cluster)
#         print(f"Cluster {i+1}: {len(cluster)} points {names}, Centroid = [{', '.join(f'{x:.2f}' for x in c)}]")

# def hierarchical_cluster(points, method):
#     clusters = [[p] for p in points]
#     iteration = 1
#     while len(clusters) > 1:
#         print(f"\n--- Iteration {iteration} ---")
#         print_clusters(clusters)
#         print_distance_matrix(clusters, method)

#         min_dist = float("inf")
#         mergeA, mergeB = -1, -1
#         for i in range(len(clusters)):
#             for j in range(i + 1, len(clusters)):
#                 d = linkage_distance(clusters[i], clusters[j], method)
#                 if d < min_dist:
#                     min_dist = d
#                     mergeA, mergeB = i, j

#         print(f"\nMerging clusters {mergeA+1} and {mergeB+1} (distance={min_dist:.2f})")
#         clusters[mergeA].extend(clusters[mergeB])
#         clusters.pop(mergeB)
#         iteration += 1

#     print("\n--- Final Cluster ---")
#     final_cluster = clusters[0]
#     final_names = [p[0] for p in final_cluster]
#     final_centroid = centroid(final_cluster)
#     print(f"Final Cluster: {len(final_cluster)} points {final_names}")
#     print(f"Centroid: [{', '.join(f'{x:.2f}' for x in final_centroid)}]")


# filename = input("Enter the CSV filename: ")
# all_points = read_csv(filename)
# cols_input = input("Enter column indices to use (excluding name column): ")
# cols = list(map(int, cols_input.strip().split()))
# points = [(name, [coords[i] for i in cols]) for name, coords in all_points]
# method = input("Enter linkage method (single / average / complete): ").strip().lower()
# hierarchical_cluster(points, method)
