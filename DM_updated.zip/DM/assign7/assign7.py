import csv

# --- Compute mean ---
def mean(values):
    return sum(values) / len(values)

# --- Compute Pearson correlation coefficient ---
def pearson_correlation(x, y):
    if len(x) != len(y):
        raise ValueError("Can't calculate as len(x) != len(y)")

    mean_x = mean(x)
    mean_y = mean(y)

    numerator = sum((a - mean_x) * (b - mean_y) for a, b in zip(x, y))
    denominator_x = sum((a - mean_x) ** 2 for a in x)
    denominator_y = sum((b - mean_y) ** 2 for b in y)
    denominator = (denominator_x * denominator_y) ** 0.5

    if denominator == 0:
        return 0
    return numerator / denominator


# --- Read numeric columns from a CSV file ---
def read_csv(filename):
    with open(filename, newline="") as csvfile:
        reader = csv.reader(csvfile)
        header = next(reader)
        data = list(reader)

    print("\nColumns found in CSV:")
    for i, col in enumerate(header):
        print(f"{i+1}. {col}")

    # Ask user which columns to use
    try:
        x_col = int(input("\nEnter column number for X: ")) - 1
        y_col = int(input("Enter column number for Y: ")) - 1
    except ValueError:
        print("Invalid input! Exiting.")
        return None, None

    x, y = [], []
    for row in data:
        try:
            x_val = float(row[x_col])
            y_val = float(row[y_col])
            x.append(x_val)
            y.append(y_val)
        except (ValueError, IndexError):
            continue  # skip invalid rows

    return x, y, header[x_col], header[y_col]


# --- Main program ---
if __name__ == "__main__":
    filename = input("Enter CSV filename: ").strip()
    x, y, x_name, y_name = read_csv(filename)

    if not x or not y:
        print("No valid numeric data found!")
    elif len(x) != len(y):
        print("Error: X and Y columns have different valid lengths!")
    else:
        r = pearson_correlation(x, y)
        print(f"\nPearson correlation coefficient (r) between '{x_name}' and '{y_name}': {r:.4f}")

        # Interpretation
        if r == 1:
            print("Perfect positive correlation")
        elif r == -1:
            print("Perfect negative correlation")
        elif r > 0:
            print("Positive correlation")
        elif r < 0:
            print("Negative correlation")
        else:
            print("No correlation")

# #correlation coefficient
# def mean(values):
#     return sum(values) / len(values)

# def pearson_correlation(x, y):
#     if len(x) != len(y):
#         raise ValueError("Can't calculate as len(x) != len(y)")

#     mean_x = mean(x)
#     mean_y = mean(y)

#     numerator = sum((a - mean_x) * (b - mean_y) for a, b in zip(x, y))
#     denominator_x = sum((a - mean_x) ** 2 for a in x)
#     denominator_y = sum((b - mean_y) ** 2 for b in y)

#     denominator = (denominator_x * denominator_y) ** 0.5
#     if denominator == 0:
#         return 0  

#     return numerator / denominator

# if __name__ == "__main__":
#     n = int(input("Enter number of data points: "))

#     print("Enter values for X:")
#     x = list(map(float, input().split()))
#     print("Enter values for Y:")
#     y = list(map(float, input().split()))

#     if len(x) != n or len(y) != n:
#         print("Error!")
#     else:
#         r = pearson_correlation(x, y)
#         print(f"\nPearson correlation coefficient (r): {r:.4f}")

#         if r == 1:
#             print("Perfect positive correlation")
#         elif r == -1:
#             print("Perfect negative correlation")
#         elif r > 0:
#             print("Positive correlation")
#         elif r < 0:
#             print("Negative correlation")
#         else:
#             print("No correlation")
