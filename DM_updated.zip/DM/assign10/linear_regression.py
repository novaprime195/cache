import csv

def read_csv_points(filename):
    x, y = [], []
    with open(filename, 'r') as f:
        reader = csv.reader(f)
        header_skipped = False
        for row in reader:
            if not row:
                continue
            # Skip header if it contains text
            if not header_skipped and any(v.replace('.', '', 1).isdigit() == False for v in row):
                header_skipped = True
                continue
            try:
                a, b = map(float, row[:2])
                x.append(a)
                y.append(b)
            except:
                continue
    return x, y


def linear_regression(x, y):
    n = len(x)
    if n == 0:
        raise ValueError("No data points found in CSV!")

    sum_x = sum(x)
    sum_y = sum(y)
    sum_xy = sum(x[i] * y[i] for i in range(n))
    sum_x2 = sum(val ** 2 for val in x)

    denominator = (n * sum_x2) - (sum_x ** 2)
    b = ((n * sum_xy) - (sum_x * sum_y)) / denominator
    a = (sum_y - (sum_x * b)) / n
    return a, b


def main():
    filename = input("Enter CSV filename: ").strip()
    x, y = read_csv_points(filename)

    print(f"\nLoaded {len(x)} data points.")
    a, b = linear_regression(x, y)

    if a >= 0:
        equation = f"Y = {b:.3f}X + {a:.3f}"
    else:
        equation = f"Y = {b:.3f}X - {abs(a):.3f}"

    print("\n--- Linear Regression Result ---")
    print(f"Linear Regression Equation: {equation}")
    print(f"Intercept (c): {a:.3f}")
    print(f"Slope (m): {b:.3f}")


if __name__ == "__main__":
    main()


# n = int(input("Enter number of data points: "))
# x = []
# y = []
# print("Enter data as: X Y (space-separated)")
# for _ in range(n):
#     a, b = map(float, input().split())
#     x.append(a)
#     y.append(b)

# sum_x = sum(x)
# sum_y = sum(y)
# sum_xy = sum(x[i] * y[i] for i in range(n))
# sum_x2 = sum(val ** 2 for val in x)

# denominator = (n * sum_x2) - (sum_x ** 2)
# b = ((n * sum_xy) - (sum_x * sum_y)) / denominator
# a = ((sum_y * sum_x2) - (sum_x * sum_xy)) / denominator
# if a >= 0:
#     equation = f"Y = {b:.3f}X + {a:.3f}"
# else:
#     equation = f"Y = {b:.3f}X - {abs(a):.3f}"

# print(f"\nLinear Regression Equation: {equation}")
# print(f"Intercept (c): {a:.3f}")
# print(f"Slope (m): {b:.3f}")