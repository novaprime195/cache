import math

# Read CSV file
filename = input("Enter CSV file name (e.g., play_tennis.csv): ")
data = []
with open(filename, 'r') as f:
    lines = f.readlines()
headers = lines[0].strip().split(',')
for line in lines[1:]:
    data.append(line.strip().split(','))

target_index = len(headers) - 1
n = len(data)

# Get distinct class labels
classes = set(row[target_index] for row in data)

# Get user input
user_input = {}
for i in range(len(headers) - 1):
    val = input(f"Enter {headers[i]}: ")
    user_input[headers[i]] = val

# Helper functions
def is_numeric(s):
    try:
        float(s)
        return True
    except ValueError:
        return False

def mean(values):
    return sum(values) / len(values)

def stddev(values, mu):
    return math.sqrt(sum((v - mu)**2 for v in values) / len(values))

def gaussian_prob(x, mu, sd):
    if sd == 0:  # Avoid division by zero
        return 1e-6
    return (1 / (math.sqrt(2 * math.pi) * sd)) * math.exp(-((x - mu) ** 2) / (2 * sd ** 2))

# Calculate class probabilities
class_prob = {}
for c in classes:
    count_class = sum(1 for row in data if row[target_index].lower() == c.lower())
    prior = count_class / n

    likelihood = 1.0
    for i in range(len(headers) - 1):
        feature = headers[i]
        user_val = user_input[feature]
        numeric = is_numeric(data[0][i])

        if numeric:
            class_values = [float(row[i]) for row in data if row[target_index].lower() == c.lower()]
            mu = mean(class_values)
            sd = stddev(class_values, mu)
            x = float(user_val)
            prob = gaussian_prob(x, mu, sd)
            likelihood *= prob if prob != 0 else 1e-6
        else:
            match = sum(1 for row in data if row[target_index].lower() == c.lower() and row[i].lower() == user_val.lower())
            likelihood *= (match / count_class) if match != 0 else 1e-6

    class_prob[c] = prior * likelihood

# Show results
print("\n--- Naive Bayes Classification ---")
for c in classes:
    print(f"P({c}|X) = {class_prob[c]:.8f}")

predicted = max(class_prob, key=class_prob.get)
print(f"\nPredicted Class: {predicted}")



# def read_csv(filename):
#     dataset = []
#     labels = []
#     with open(filename, "r") as f:
#         for line in f:
#             line = line.strip()
#             if not line:
#                 continue
#             parts = line.split(",")
#             dataset.append(parts[:-1])
#             labels.append(parts[-1])
#     return dataset, labels

# def summarize_by_class(dataset, labels):
#     summaries = {}
#     for cls in set(labels):
#         cls_rows = [dataset[i] for i in range(len(dataset)) if labels[i] == cls]
#         feature_counts = []
#         for col in zip(*cls_rows):
#             counts = {}
#             for value in col:
#                 counts[value] = counts.get(value, 0) + 1
#             feature_counts.append(counts)
#         summaries[cls] = feature_counts
#     return summaries

# def calculate_class_probabilities(summaries, labels, input_vector):
#     total_count = len(labels)
#     label_counts = {cls: labels.count(cls) for cls in set(labels)}
#     probabilities = {}
    
#     for cls, feature_counts in summaries.items():
#         prob = label_counts[cls] / total_count
#         for i, value in enumerate(input_vector):
#             count = feature_counts[i].get(value, 0) + 1
#             total = sum(feature_counts[i].values()) + len(feature_counts[i])
#             prob *= count / total
#         probabilities[cls] = prob
#     return probabilities

# def predict(summaries, labels, input_vector):
#     probs = calculate_class_probabilities(summaries, labels, input_vector)
#     best_label = max(probs, key=probs.get)
#     return best_label

# if __name__ == "__main__":
#     choice = input("Do you want to use CSV file? (y/n): ").strip().lower()

#     if choice == "y":
#         filename = input("Enter CSV filename: ").strip()
#         dataset, labels = read_csv(filename)
#     else:
#         n = int(input("Enter number of data points: "))
#         m = int(input("Enter number of features: "))
#         dataset = []
#         labels = []
#         print("Enter data row by row (features followed by label, space-separated):")
#         for _ in range(n):
#             row = input().strip().split()
#             if len(row) != m + 1:
#                 print(f"Error: each row must have {m} features + 1 label")
#                 exit()
#             dataset.append(row[:-1])
#             labels.append(row[-1])

#     summaries = summarize_by_class(dataset, labels)

#     print("\nEnter feature values to predict:")
#     input_vector = input().strip().split()
#     if len(input_vector) != len(dataset[0]):
#         print(f"Error: input must have {len(dataset[0])} feature values")
#         exit()

#     predicted_label = predict(summaries, labels, input_vector)
#     print(f"\nPredicted class: {predicted_label}")


