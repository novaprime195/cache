#include <bits/stdc++.h>
using namespace std;

vector<string> split(const string &s, char d) {
    vector<string> t; string x; stringstream ss(s);
    while (getline(ss, x, d)) t.push_back(x);
    return t;
}

int main() {
    string filename;
    cout << "Enter CSV filename: ";
    cin >> filename;

    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error: Cannot open file.\n";
        return 1;
    }

    string line;
    getline(file, line);
    vector<string> headers = split(line, ',');
    int n = headers.size() - 1;

    vector<vector<string>> data;
    while (getline(file, line)) {
        vector<string> row = split(line, ',');
        if (row.size() == headers.size()) data.push_back(row);
    }
    file.close();

    map<string, int> classCount;
    for (auto &r : data) classCount[r.back()]++;
    int total = data.size();

    cout << "\nPrior Probabilities:\n";
    map<string, double> prior;
    for (auto &c : classCount) {
        prior[c.first] = (double)c.second / total;
        cout << "P(" << c.first << ") = " << classCount[c.first] << "/" << total
             << " = " << fixed << setprecision(3) << prior[c.first] << endl;
    }

    cout << "\nConditional Probabilities:\n";
    map<string, map<string, map<string, double>>> featureProb;
    for (int i = 0; i < n; i++) {
        map<string, map<string, int>> freq;
        for (auto &r : data) freq[r.back()][r[i]]++;

        for (auto &c : classCount) {
            cout << "\nFor Class = " << c.first << " (" << headers[i] << "):\n";
            for (auto &f : freq[c.first]) {
                featureProb[headers[i]][c.first][f.first] =
                    (double)f.second / classCount[c.first];
                cout << "P(" << f.first << " | " << c.first << ") = "
                     << f.second << "/" << classCount[c.first]
                     << " = " << featureProb[headers[i]][c.first][f.first] << endl;
            }
        }
    }

    cout << "\nEnter values for a test case:\n";
    map<string, string> inst;
    for (int i = 0; i < n; i++) {
        string v;
        cout << headers[i] << ": ";
        cin >> v;
        inst[headers[i]] = v;
    }

    cout << "\nCalculation of Posterior Probabilities:\n";
    map<string, double> post;

    for (auto &c : classCount) {
        double prob = prior[c.first];
        cout << "\nFor " << c.first << ":\n";
        cout << "P(" << c.first << ") = " << prior[c.first] << endl;
        for (int i = 0; i < n; i++) {
            string f = headers[i], v = inst[f];
            double cond = featureProb[f][c.first].count(v) ?
                          featureProb[f][c.first][v] : 0.0;
            cout << "P(" << v << " | " << c.first << ") = " << cond << endl;
            prob *= cond;
        }
        cout << "=> Final P(" << c.first << " | Case) = " << prob << endl;
        post[c.first] = prob;
    }

    cout << "\nComparison:\n";
    for (auto &p : post)
        cout << "P(" << p.first << " | Case) = " << p.second << endl;

    string pred = max_element(post.begin(), post.end(),
                              [](auto &a, auto &b) {
                                  return a.second < b.second;
                              })->first;

    cout << "\nBased on calculations:\nPredicted classification for case is "
         << pred << endl;

    return 0;
}


//When Quantitative Data is given as input
// #include <iostream>
// #include <fstream>
// #include <sstream>
// #include <vector>
// #include <map>
// #include <set>
// #include <cmath>
// #include <algorithm>
// #include <iomanip>
// #include <strings.h>


// using namespace std;

// // --- Helper functions ---

// bool is_numeric(const string &s) {
//     if (s.empty()) return false;
//     char *endptr = nullptr;
//     strtod(s.c_str(), &endptr);
//     return (*endptr == '\0');
// }

// double mean(const vector<double> &values) {
//     double sum = 0.0;
//     for (double v : values) sum += v;
//     return sum / values.size();
// }

// double stddev(const vector<double> &values, double mu) {
//     double sum_sq = 0.0;
//     for (double v : values)
//         sum_sq += pow(v - mu, 2);
//     return sqrt(sum_sq / values.size());
// }

// double gaussian_prob(double x, double mu, double sd) {
//     if (sd == 0.0)
//         return 1e-6;
//     double exponent = exp(-pow(x - mu, 2) / (2 * pow(sd, 2)));
//     return (1 / (sqrt(2 * M_PI) * sd)) * exponent;
// }

// // --- Main program ---
// int main() {
//     string filename;
//     cout << "Enter CSV file name (e.g., play_tennis.csv): ";
//     getline(cin, filename);

//     ifstream file(filename);
//     if (!file.is_open()) {
//         cerr << "Error: Cannot open file.\n";
//         return 1;
//     }

//     vector<string> headers;
//     vector<vector<string>> data;
//     string line;

//     // --- Read CSV ---
//     if (getline(file, line)) {
//         stringstream ss(line);
//         string cell;
//         while (getline(ss, cell, ','))
//             headers.push_back(cell);
//     }

//     while (getline(file, line)) {
//         stringstream ss(line);
//         string cell;
//         vector<string> row;
//         while (getline(ss, cell, ','))
//             row.push_back(cell);
//         if (!row.empty())
//             data.push_back(row);
//     }
//     file.close();

//     if (data.empty()) {
//         cerr << "Error: CSV contains no data.\n";
//         return 1;
//     }

//     size_t target_index = headers.size() - 1;
//     size_t n = data.size();

//     // --- Collect distinct class labels ---
//     set<string> classes;
//     for (const auto &row : data)
//         classes.insert(row[target_index]);

//     // --- Get user input ---
//     map<string, string> user_input;
//     for (size_t i = 0; i < headers.size() - 1; ++i) {
//         string val;
//         cout << "Enter " << headers[i] << ": ";
//         getline(cin, val);
//         user_input[headers[i]] = val;
//     }

//     // --- Calculate class probabilities ---
//     map<string, double> class_prob;

//     for (const string &c : classes) {
//         // count how many samples of this class
//         int count_class = 0;
//         for (const auto &row : data)
//             if (strcasecmp(row[target_index].c_str(), c.c_str()) == 0)
//                 count_class++;

//         double prior = static_cast<double>(count_class) / n;
//         double likelihood = 1.0;

//         for (size_t i = 0; i < headers.size() - 1; ++i) {
//             string feature = headers[i];
//             string user_val = user_input[feature];
//             bool numeric = is_numeric(data[0][i]);

//             if (numeric) {
//                 vector<double> class_values;
//                 for (const auto &row : data)
//                     if (strcasecmp(row[target_index].c_str(), c.c_str()) == 0)
//                         class_values.push_back(stod(row[i]));

//                 double mu = mean(class_values);
//                 double sd = stddev(class_values, mu);
//                 double x = stod(user_val);
//                 double prob = gaussian_prob(x, mu, sd);
//                 likelihood *= (prob != 0 ? prob : 1e-6);
//             } else {
//                 int match = 0;
//                 for (const auto &row : data)
//                     if (strcasecmp(row[target_index].c_str(), c.c_str()) == 0 &&
//                         strcasecmp(row[i].c_str(), user_val.c_str()) == 0)
//                         match++;
//                 double prob = (count_class > 0) ? static_cast<double>(match) / count_class : 1e-6;
//                 likelihood *= (prob != 0 ? prob : 1e-6);
//             }
//         }

//         class_prob[c] = prior * likelihood;
//     }

//     // --- Display results ---
//     cout << "\n--- Naive Bayes Classification ---\n";
//     cout << fixed << setprecision(8);
//     for (const auto &kv : class_prob)
//         cout << "P(" << kv.first << "|X) = " << kv.second << "\n";

//     // Find class with maximum probability
//     string predicted;
//     double max_prob = -1.0;
//     for (const auto &kv : class_prob) {
//         if (kv.second > max_prob) {
//             max_prob = kv.second;
//             predicted = kv.first;
//         }
//     }

//     cout << "\nPredicted Class: " << predicted << endl;

//     return 0;
// }